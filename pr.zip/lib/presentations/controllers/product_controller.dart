/*

import 'package:get/get.dart';
import 'package:retoverse/data/models/product_model.dart';
import 'package:retoverse/domain/usecases/product_usecases/get_product_usecase.dart';

class ProductController extends GetxController {
  final GetProductUseCase getProductUseCase;

  ProductController({required this.getProductUseCase});

  final RxList<ProductModel> products = <ProductModel>[].obs;
  final RxBool isLoading = false.obs;
  final RxBool hasMore = true.obs;
  final RxString errorMessage = ''.obs;
  final int _limit = 10;

  @override
  void onInit() {
    super.onInit();
    loadInitialProducts();
  }

  Future<void> loadInitialProducts() async {
    if (isLoading.value) return;
    isLoading.value = true;
    errorMessage.value = '';
    products.clear();
    hasMore.value = true;
    getProductUseCase.repository.resetPagination();

    try {
      final result = await getProductUseCase(limit: _limit, reset: true);
      products.assignAll(result);
      hasMore.value = result.length == _limit;
    } catch (e) {
      errorMessage.value = 'Failed to load products: ${e.toString()}';
      Get.snackbar(
        'Error',
        errorMessage.value,
        snackPosition: SnackPosition.BOTTOM,
      );
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> loadMoreProducts() async {
    if (isLoading.value || !hasMore.value) return;
    isLoading.value = true;

    try {
      final result = await getProductUseCase(limit: _limit);
      if (result.isEmpty) {
        hasMore.value = false;
      } else {
        products.addAll(result);
        hasMore.value = result.length == _limit;
      }
    } catch (e) {
      errorMessage.value = 'Failed to load more products: ${e.toString()}';
      Get.snackbar(
        'Error',
        errorMessage.value,
        snackPosition: SnackPosition.BOTTOM,
      );
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> refreshProducts() async {
    await loadInitialProducts();
  }
}

*/

import 'package:get/get.dart';
import 'package:retoverse/data/models/product_model.dart';
import 'package:retoverse/domain/usecases/product_usecases/get_product_usecase.dart';

class ProductController extends GetxController {
  final GetProductUseCase getProductUseCase;

  ProductController({required this.getProductUseCase});

  final RxList<ProductModel> products = <ProductModel>[].obs;
  final RxList<ProductModel> filteredProducts = <ProductModel>[].obs;
  final RxBool isLoading = false.obs;
  final RxBool isLoadingMore = false.obs;
  final RxBool hasMore = true.obs;
  final RxString errorMessage = ''.obs;
  final RxString searchQuery = ''.obs;
  final RxString sortBy = 'newest'.obs;
  final int _limit = 10;

  @override
  void onInit() {
    super.onInit();
    loadInitialProducts();
    debounce(
      searchQuery,
      (_) => _applyFiltersAndSearch(),
      time: Duration(milliseconds: 500),
    );
  }

  Future<void> loadInitialProducts() async {
    if (isLoading.value) return;
    isLoading.value = true;
    errorMessage.value = '';
    products.clear();
    filteredProducts.clear();
    hasMore.value = true;
    getProductUseCase.repository.resetPagination();

    try {
      final result = await getProductUseCase(limit: _limit, reset: true);
      products.assignAll(result);
      filteredProducts.assignAll(result);
      hasMore.value = result.length == _limit;
      _sortProducts();
    } catch (e) {
      errorMessage.value = 'Failed to load products: ${e.toString()}';
      Get.snackbar(
        'Error',
        errorMessage.value,
        snackPosition: SnackPosition.BOTTOM,
      );
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> loadMoreProducts() async {
    if (isLoading.value || isLoadingMore.value || !hasMore.value) return;
    isLoadingMore.value = true;

    try {
      final result = await getProductUseCase(limit: _limit);
      if (result.isEmpty) {
        hasMore.value = false;
      } else {
        products.addAll(result);
        _applyFiltersAndSearch();
        hasMore.value = result.length == _limit;
      }
    } catch (e) {
      errorMessage.value = 'Failed to load more products: ${e.toString()}';
      Get.snackbar(
        'Error',
        errorMessage.value,
        snackPosition: SnackPosition.BOTTOM,
      );
    } finally {
      isLoadingMore.value = false;
    }
  }

  Future<void> refreshProducts() async {
    await loadInitialProducts();
  }

  void searchProducts(String query) {
    searchQuery.value = query;
  }

  void sortProducts(String sortType) {
    sortBy.value = sortType;
    _sortProducts();
  }

  void _sortProducts() {
    switch (sortBy.value) {
      case 'price_asc':
        filteredProducts.sort((a, b) => a.price.compareTo(b.price));
        break;
      case 'price_desc':
        filteredProducts.sort((a, b) => b.price.compareTo(a.price));
        break;
      case 'newest':
      default:
        filteredProducts.sort((a, b) => b.createdAt.compareTo(a.createdAt));
        break;
    }
    filteredProducts.refresh();
  }

  void _applyFiltersAndSearch() {
    if (searchQuery.isEmpty) {
      filteredProducts.assignAll(products);
    } else {
      final query = searchQuery.value.toLowerCase();
      filteredProducts.assignAll(
        products.where(
          (product) =>
              product.name.toLowerCase().contains(query) ||
              product.description.toLowerCase().contains(query),
        ),
      );
    }
    _sortProducts();
  }

  // Add this if you want to implement category filtering later
  // void filterByCategory(String category) {
  //   // Implementation for category filtering
  // }
}
