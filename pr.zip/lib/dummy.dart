import 'package:flutter/material.dart';
import 'core/utils/responsive_widget.dart';

// Entry point
void main() => runApp(const BadLiesApp());

class BadLiesApp extends StatelessWidget {
  const BadLiesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Bad Lies',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: Colors.black, useMaterial3: true),
      home: const BadLiesHomePage(),
    );
  }
}

class BadLiesHomePage extends StatelessWidget {
  const BadLiesHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return ResponsiveWidget(
      mobile: const _HomeScaffold(isDesktop: false),
      desktop: const _HomeScaffold(isDesktop: true),
    );
  }
}

class _HomeScaffold extends StatefulWidget {
  final bool isDesktop;
  const _HomeScaffold({required this.isDesktop});

  @override
  State<_HomeScaffold> createState() => _HomeScaffoldState();
}

class _HomeScaffoldState extends State<_HomeScaffold> {
  final PageController _heroCtrl = PageController();
  int _heroIndex = 0;

  // Dummy data
  final List<_BannerItem> _banners = const [
    _BannerItem(
      title: "DROP 07 — BOLD BASICS",
      subtitle: "Heavyweight tees, boxy fits, unapologetic prints.",
      cta: "Shop Now",
      icon: Icons.emoji_emotions,
      dark: true,
    ),
    _BannerItem(
      title: "URBAN ATHLEISURE",
      subtitle: "Built for streets. Ready for heat.",
      cta: "Explore",
      icon: Icons.sports_basketball,
      dark: false,
    ),
    _BannerItem(
      title: "MONOCHROME EDIT",
      subtitle: "Minimal palette. Maximum attitude.",
      cta: "View Edit",
      icon: Icons.palette,
      dark: true,
    ),
  ];

  final List<String> _categories = const [
    "New",
    "T-Shirts",
    "Hoodies",
    "Bottoms",
    "Overshirts",
    "Caps",
    "Accessories",
    "Sale",
  ];

  final List<_Product> _spotlights = List.generate(
    10,
    (i) => _Product(
      title: "Graphic Tee #$i",
      price: (999 + i * 50).toDouble(),
      icon: Icons.checkroom,
      rating: 4.3,
      stock: 12 - (i % 5),
      description: "200 GSM, boxy fit, screen printed graphic.",
    ),
  );

  final List<_Product> _newArrivals = List.generate(
    12,
    (i) => _Product(
      title: "Heavy Hoodie #$i",
      price: (1799 + i * 70).toDouble(),
      icon: Icons.emoji_people,
      rating: 4.7,
      stock: 8 + (i % 3),
      description: "Fleece lined, drop shoulder, kangaroo pocket.",
    ),
  );

  @override
  void dispose() {
    _heroCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDesktop = widget.isDesktop;
    final isTablet = !isDesktop && MediaQuery.of(context).size.width >= 700;
    final contentPadding = EdgeInsets.symmetric(
      horizontal: isDesktop
          ? 80
          : isTablet
          ? 40
          : 16,
    );

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: _ResponsiveAppBar(
        onSearchTap: () {},
        onCartTap: () {},
        onMenuTap: () {},
      ),
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _HeroSection(
                  controller: _heroCtrl,
                  banners: _banners,
                  index: _heroIndex,
                  onPageChanged: (i) => setState(() => _heroIndex = i),
                  height: isDesktop
                      ? 320
                      : isTablet
                      ? 260
                      : 200,
                ),
                Padding(
                  padding: contentPadding.copyWith(top: 24, bottom: 8),
                  child: _CategoryChips(categories: _categories, onTap: (c) {}),
                ),
                Padding(
                  padding: contentPadding.copyWith(top: 8),
                  child: _SectionHeader(
                    title: "Spotlight",
                    actionText: "View all",
                    onAction: () {},
                  ),
                ),
                SizedBox(
                  height: isDesktop ? 220 : 180,
                  child: _HorizontalProductList(
                    products: _spotlights,
                    cardWidth: isDesktop ? 180 : 140,
                  ),
                ),
                Padding(
                  padding: contentPadding.copyWith(top: 24),
                  child: _EditorialSplit(
                    leftIcon: Icons.style,
                    rightIcon: Icons.local_fire_department,
                    title: "Made for Everyday Chaos",
                    subtitle:
                        "Hard-wearing fabrics, oversized fits, and graphics that speak loud.",
                    cta: "Shop Collection",
                    onTap: () {},
                    isDesktop: isDesktop,
                  ),
                ),
                Padding(
                  padding: contentPadding.copyWith(top: 24),
                  child: _SectionHeader(
                    title: "New Arrivals",
                    actionText: "Shop new",
                    onAction: () {},
                  ),
                ),
                Padding(
                  padding: contentPadding.copyWith(top: 8),
                  child: _ProductGrid(
                    products: _newArrivals,
                    columns: isDesktop
                        ? 4
                        : isTablet
                        ? 3
                        : 2,
                    aspectRatio: isDesktop ? 3 / 4 : 3 / 4.3,
                  ),
                ),
                Padding(
                  padding: contentPadding.copyWith(top: 32),
                  child: _NewsletterBar(isDesktop: isDesktop),
                ),
                const SizedBox(height: 24),
                Container(
                  color: const Color(0xFF0D0D0D),
                  padding: contentPadding.copyWith(top: 32, bottom: 32),
                  child: const _Footer(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/* ----------------------------- APP BAR ---------------------------------- */

class _ResponsiveAppBar extends StatelessWidget implements PreferredSizeWidget {
  final VoidCallback onSearchTap, onCartTap, onMenuTap;
  const _ResponsiveAppBar({
    required this.onSearchTap,
    required this.onCartTap,
    required this.onMenuTap,
  });

  @override
  Size get preferredSize => const Size.fromHeight(64);

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, c) {
        final isDesktop = c.maxWidth >= 1024;
        return AppBar(
          surfaceTintColor: Colors.white,
          backgroundColor: Colors.white,
          elevation: 0.4,
          centerTitle: false,
          titleSpacing: isDesktop ? 32 : 16,
          title: Row(
            children: [
              const _BrandWordmark(),
              const Spacer(),
              if (isDesktop)
                SizedBox(width: 340, child: _SearchField(onTap: onSearchTap)),
              const Spacer(),
              IconButton(
                tooltip: "Search",
                onPressed: onSearchTap,
                icon: const Icon(Icons.search),
              ),
              IconButton(
                tooltip: "Account",
                onPressed: () {},
                icon: const Icon(Icons.person_outline),
              ),
              Stack(
                alignment: Alignment.topRight,
                children: [
                  IconButton(
                    tooltip: "Cart",
                    onPressed: onCartTap,
                    icon: const Icon(Icons.shopping_bag_outlined),
                  ),
                  Positioned(
                    right: 8,
                    top: 8,
                    child: Container(
                      height: 10,
                      width: 10,
                      decoration: const BoxDecoration(
                        color: Colors.red,
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
                ],
              ),
              if (!isDesktop)
                IconButton(
                  tooltip: "Menu",
                  onPressed: onMenuTap,
                  icon: const Icon(Icons.menu),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _BrandWordmark extends StatelessWidget {
  const _BrandWordmark();

  @override
  Widget build(BuildContext context) => Text(
    "BAD LIES",
    style: Theme.of(context).textTheme.titleLarge?.copyWith(
      letterSpacing: 6,
      fontWeight: FontWeight.w800,
    ),
  );
}

class _SearchField extends StatelessWidget {
  final VoidCallback onTap;
  const _SearchField({required this.onTap});

  @override
  Widget build(BuildContext context) => TextField(
    onTap: onTap,
    readOnly: true,
    decoration: InputDecoration(
      hintText: "Search products",
      isDense: true,
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      prefixIcon: const Icon(Icons.search),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
    ),
  );
}

/* ----------------------------- HERO ------------------------------------- */

class _HeroSection extends StatelessWidget {
  final PageController controller;
  final List<_BannerItem> banners;
  final int index;
  final double height;
  final ValueChanged<int> onPageChanged;

  const _HeroSection({
    required this.controller,
    required this.banners,
    required this.index,
    required this.onPageChanged,
    required this.height,
  });

  @override
  Widget build(BuildContext context) => SizedBox(
    height: height,
    child: Stack(
      children: [
        PageView.builder(
          controller: controller,
          onPageChanged: onPageChanged,
          itemCount: banners.length,
          itemBuilder: (_, i) => _HeroSlide(item: banners[i]),
        ),
        Positioned(
          bottom: 16,
          left: 0,
          right: 0,
          child: Center(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: List.generate(
                banners.length,
                (i) => AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  height: 8,
                  width: i == index ? 24 : 8,
                  decoration: BoxDecoration(
                    color: i == index ? Colors.black : Colors.black26,
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    ),
  );
}

class _HeroSlide extends StatelessWidget {
  final _BannerItem item;
  const _HeroSlide({required this.item});

  @override
  Widget build(BuildContext context) => Stack(
    children: [
      Positioned.fill(
        child: Container(
          color: item.dark ? Colors.black87 : Colors.grey[300],
          child: Center(
            child: Icon(
              item.icon,
              size: 100,
              color: item.dark ? Colors.white : Colors.black,
            ),
          ),
        ),
      ),
      Positioned.fill(
        child: DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.black.withOpacity(item.dark ? 0.55 : 0.25),
                Colors.transparent,
              ],
              begin: Alignment.bottomCenter,
              end: Alignment.center,
            ),
          ),
        ),
      ),
      Positioned(
        left: 24,
        right: 24,
        bottom: 36,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 900),
          child: Wrap(
            runSpacing: 12,
            children: [
              Text(
                item.title,
                style: Theme.of(context).textTheme.displaySmall?.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.w800,
                  height: 1.0,
                  letterSpacing: -0.5,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                item.subtitle,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: Colors.white70,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 12),
              FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 18,
                    vertical: 14,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                onPressed: () {},
                child: Text(item.cta),
              ),
            ],
          ),
        ),
      ),
    ],
  );
}

/* --------------------------- CATEGORIES --------------------------------- */

class _CategoryChips extends StatelessWidget {
  final List<String> categories;
  final ValueChanged<String> onTap;
  const _CategoryChips({required this.categories, required this.onTap});

  @override
  Widget build(BuildContext context) => SizedBox(
    height: 44,
    child: ListView.separated(
      scrollDirection: Axis.horizontal,
      itemCount: categories.length,
      separatorBuilder: (_, __) => const SizedBox(width: 8),
      itemBuilder: (_, i) => ActionChip(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        label: Text(categories[i]),
        onPressed: () => onTap(categories[i]),
      ),
    ),
  );
}

/* --------------------------- SECTION HEADER ----------------------------- */

class _SectionHeader extends StatelessWidget {
  final String title, actionText;
  final VoidCallback onAction;
  const _SectionHeader({
    required this.title,
    required this.actionText,
    required this.onAction,
  });

  @override
  Widget build(BuildContext context) => Row(
    children: [
      Text(
        title,
        style: Theme.of(
          context,
        ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800),
      ),
      const Spacer(),
      TextButton(onPressed: onAction, child: Text(actionText)),
    ],
  );
}

/* ------------------------- HORIZONTAL LIST ------------------------------ */

class _HorizontalProductList extends StatelessWidget {
  final List<_Product> products;
  final double cardWidth;
  const _HorizontalProductList({
    required this.products,
    required this.cardWidth,
  });

  @override
  Widget build(BuildContext context) => ListView.separated(
    padding: const EdgeInsets.symmetric(horizontal: 16),
    scrollDirection: Axis.horizontal,
    itemCount: products.length,
    separatorBuilder: (_, __) => const SizedBox(width: 16),
    itemBuilder: (_, i) => SizedBox(
      width: cardWidth,
      child: _ProductCard(product: products[i]),
    ),
  );
}

/* --------------------------- EDITORIAL SPLIT ---------------------------- */

class _EditorialSplit extends StatelessWidget {
  final IconData leftIcon, rightIcon;
  final String title, subtitle, cta;
  final VoidCallback onTap;
  final bool isDesktop;

  const _EditorialSplit({
    required this.leftIcon,
    required this.rightIcon,
    required this.title,
    required this.subtitle,
    required this.cta,
    required this.onTap,
    required this.isDesktop,
  });

  @override
  Widget build(BuildContext context) {
    final left = _EditorialTile(icon: leftIcon);
    final right = _EditorialTextBlock(
      icon: rightIcon,
      title: title,
      subtitle: subtitle,
      cta: cta,
      onTap: onTap,
    );
    return isDesktop
        ? Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(child: left),
              const SizedBox(width: 16),
              Expanded(child: right),
            ],
          )
        : Column(children: [left, const SizedBox(height: 12), right]);
  }
}

class _EditorialTile extends StatelessWidget {
  final IconData icon;
  const _EditorialTile({required this.icon});

  @override
  Widget build(BuildContext context) => AspectRatio(
    aspectRatio: 16 / 10,
    child: Container(
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.circular(16),
      ),
      child: Center(child: Icon(icon, size: 80, color: Colors.black54)),
    ),
  );
}

class _EditorialTextBlock extends StatelessWidget {
  final IconData icon;
  final String title, subtitle, cta;
  final VoidCallback onTap;

  const _EditorialTextBlock({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.cta,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(
      color: const Color(0xFFF5F5F5),
      borderRadius: BorderRadius.circular(16),
    ),
    child: Row(
      children: [
        Icon(icon, size: 48, color: Colors.black45),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 8),
              Text(subtitle, style: Theme.of(context).textTheme.bodyLarge),
              const SizedBox(height: 14),
              FilledButton(onPressed: onTap, child: Text(cta)),
            ],
          ),
        ),
      ],
    ),
  );
}

/* --------------------------- PRODUCT GRID ------------------------------- */

class _ProductGrid extends StatelessWidget {
  final List<_Product> products;
  final int columns;
  final double aspectRatio;

  const _ProductGrid({
    required this.products,
    required this.columns,
    required this.aspectRatio,
  });

  @override
  Widget build(BuildContext context) => GridView.builder(
    itemCount: products.length,
    shrinkWrap: true,
    physics: const NeverScrollableScrollPhysics(),
    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
      crossAxisCount: columns,
      crossAxisSpacing: 16,
      mainAxisSpacing: 16,
      childAspectRatio: aspectRatio,
    ),
    itemBuilder: (_, i) => _ProductCard(product: products[i]),
  );
}

class _ProductCard extends StatelessWidget {
  final _Product product;
  const _ProductCard({required this.product});

  @override
  Widget build(BuildContext context) => InkWell(
    onTap: () {},
    borderRadius: BorderRadius.circular(14),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        AspectRatio(
          aspectRatio: 1,
          child: Container(
            decoration: BoxDecoration(
              color: Colors.grey[200],
              borderRadius: BorderRadius.circular(14),
            ),
            child: Stack(
              fit: StackFit.expand,
              children: [
                Center(
                  child: Icon(product.icon, size: 48, color: Colors.black54),
                ),
                if (product.stock <= 2)
                  Positioned(
                    left: 8,
                    top: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.7),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Text(
                        "LOW STOCK",
                        style: TextStyle(color: Colors.white, fontSize: 11),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          product.title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: Theme.of(
            context,
          ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 2),
        Row(
          children: [
            const Icon(Icons.star, size: 16),
            const SizedBox(width: 4),
            Text(product.rating.toStringAsFixed(1)),
            const Spacer(),
            Text(
              "₹${product.price.toStringAsFixed(0)}",
              style: Theme.of(
                context,
              ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
            ),
          ],
        ),
      ],
    ),
  );
}

/* ---------------------------- NEWSLETTER -------------------------------- */

class _NewsletterBar extends StatelessWidget {
  final bool isDesktop;
  const _NewsletterBar({required this.isDesktop});

  @override
  Widget build(BuildContext context) {
    final controller = TextEditingController();
    if (isDesktop) {
      return IntrinsicHeight(
        child: Row(
          children: [
            Expanded(
              child: Text(
                "Join the Bad List",
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Text(
                "Early access to drops, limited runs, and insider deals.",
                style: Theme.of(
                  context,
                ).textTheme.bodyLarge?.copyWith(color: Colors.white70),
              ),
            ),
            const SizedBox(width: 16),
            SizedBox(
              width: 360,
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: controller,
                      style: const TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        hintText: "Enter your email",
                        hintStyle: const TextStyle(color: Colors.white70),
                        filled: true,
                        fillColor: Colors.white.withOpacity(0.06),
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 12,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  FilledButton(
                    onPressed: () {},
                    style: FilledButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.black,
                    ),
                    child: const Text("Subscribe"),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    } else {
      // Fix overflow by wrapping in SingleChildScrollView and adding min height
      return ConstrainedBox(
        constraints: const BoxConstraints(minHeight: 0, maxHeight: 220),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Join the Bad List",
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                "Early access to drops, limited runs, and insider deals.",
                style: Theme.of(
                  context,
                ).textTheme.bodyLarge?.copyWith(color: Colors.white70),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: controller,
                      style: const TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        hintText: "Enter your email",
                        hintStyle: const TextStyle(color: Colors.white70),
                        filled: true,
                        fillColor: Colors.white.withOpacity(0.06),
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 12,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  FilledButton(
                    onPressed: () {},
                    style: FilledButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.black,
                    ),
                    child: const Text("Subscribe"),
                  ),
                ],
              ),
            ],
          ),
        ),
      );
    }
  }
}

/* -------------------------------- FOOTER -------------------------------- */

class _Footer extends StatelessWidget {
  const _Footer();

  @override
  Widget build(BuildContext context) {
    final linkStyle = Theme.of(
      context,
    ).textTheme.bodyMedium?.copyWith(color: Colors.white70);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Wrap(
          spacing: 48,
          runSpacing: 24,
          children: [
            SizedBox(
              width: 260,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "BAD LIES",
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      color: Colors.white,
                      letterSpacing: 4,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Bold, lifestyle-driven designs from Delhi, India.",
                    style: linkStyle,
                  ),
                ],
              ),
            ),
            _FooterColumn(
              title: "Shop",
              children: [
                "New",
                "T-Shirts",
                "Hoodies",
                "Bottoms",
                "Accessories",
              ],
              style: linkStyle,
            ),
            _FooterColumn(
              title: "Help",
              children: ["Shipping", "Returns", "FAQ", "Contact"],
              style: linkStyle,
            ),
            _FooterColumn(
              title: "Company",
              children: ["About", "Careers", "Terms", "Privacy"],
              style: linkStyle,
            ),
          ],
        ),
        const SizedBox(height: 24),
        const Divider(color: Colors.white24),
        const SizedBox(height: 12),
        Row(
          children: [
            Text(
              "© ${DateTime.now().year} Bad Lies",
              style: linkStyle?.copyWith(color: Colors.white60),
            ),
            const Spacer(),
            IconButton(
              onPressed: () {},
              icon: const Icon(Icons.camera_alt_outlined, color: Colors.white),
              tooltip: "Instagram",
            ),
            IconButton(
              onPressed: () {},
              icon: const Icon(Icons.ondemand_video, color: Colors.white),
              tooltip: "YouTube",
            ),
            IconButton(
              onPressed: () {},
              icon: const Icon(Icons.facebook_outlined, color: Colors.white),
              tooltip: "Facebook",
            ),
          ],
        ),
      ],
    );
  }
}

class _FooterColumn extends StatelessWidget {
  final String title;
  final List<String> children;
  final TextStyle? style;
  const _FooterColumn({
    required this.title,
    required this.children,
    required this.style,
  });

  @override
  Widget build(BuildContext context) => SizedBox(
    width: 160,
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            color: Colors.white,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 8),
        for (final c in children)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Text(c, style: style),
          ),
      ],
    ),
  );
}

/* ------------------------------- MODELS --------------------------------- */

class _BannerItem {
  final String title, subtitle, cta;
  final IconData icon;
  final bool dark;
  const _BannerItem({
    required this.title,
    required this.subtitle,
    required this.cta,
    required this.icon,
    required this.dark,
  });
}

class _Product {
  final String title, description;
  final double price, rating;
  final int stock;
  final IconData icon;
  const _Product({
    required this.title,
    required this.price,
    required this.icon,
    required this.rating,
    required this.stock,
    required this.description,
  });
}

/* ---------------------------- QUICK START ------------------------------- */
