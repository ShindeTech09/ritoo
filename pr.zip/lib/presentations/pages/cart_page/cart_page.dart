import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../controllers/cart_controller.dart';
import '../../widgets/app_scaffold.dart';

class CartPage extends StatelessWidget {
  final CartController controller = Get.find<CartController>();

  CartPage({super.key});
  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'Cart',
      body: Obx(() {
        if (controller.cartItems.isEmpty) {
          return Center(child: Text('Your cart is empty.'));
        }
        return ListView.builder(
          itemCount: controller.cartItems.length,
          itemBuilder: (context, index) {
            final item = controller.cartItems[index];
            return ListTile(
              leading: Image.network(
                item.imageUrl,
                width: 50,
                height: 50,
                fit: BoxFit.cover,
              ),
              title: Text(item.name, style: TextStyle(fontSize: 20.0)),
              subtitle: Text('₹${item.price} x ${item.quantity}'),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: Icon(Icons.remove),
                    onPressed: () => controller.updateQuantity(
                      item.productId,
                      item.quantity - 1,
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.add),
                    onPressed: () => controller.updateQuantity(
                      item.productId,
                      item.quantity + 1,
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.delete),
                    onPressed: () => controller.removeFromCart(item.productId),
                  ),
                ],
              ),
            );
          },
        );
      }),
      floatingActionButton: Obx(
        () => controller.cartItems.isEmpty
            ? SizedBox.shrink()
            : FloatingActionButton.extended(
                onPressed: () {
                  // TODO: Implement checkout
                },
                label: Text('Checkout'),
                icon: Icon(Icons.payment),
              ),
      ),
    );
  }
}
